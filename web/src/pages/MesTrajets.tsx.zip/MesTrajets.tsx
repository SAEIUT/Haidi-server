import React, { useState, useEffect } from "react";
import TrajetList from "../components/MesTrajets/TrajetList";
import FiltreTrajets from "../components/MesTrajets/FiltreTrajets";
import { Trajet } from '../components/MesTrajets/TrajetList'; 
import HomeNavbar from '../components/HomeNavbar';

interface SousTrajet {
  BD: string;
  numDossier: number;
  statusValue: number;
  departure: string;
  arrival: string;
  departureTime: string;
  arrivalTime: string;
}

interface Dossier {
  idDossier: number;
  idPMR: number;
  googleId: string;
  enregistre: boolean;
  bagage: {
    bagagesList: number[];
    specialBagage: string;
  };
  specialAssistance: {
    wheelchair: boolean;
    visualAssistance: boolean;
    hearingAssistance: boolean;
    otherAssistance: string;
  };
  security: {
    securityQuestions: {
      packedOwn: boolean;
      leftUnattended: boolean;
      acceptedItems: boolean;
      receivedItems: boolean;
      dangerousGoods: boolean;
    };
    declarations: {
      weaponsFirearms: boolean;
      explosives: boolean;
      flammableMaterials: boolean;
      radioactiveMaterials: boolean;
      toxicSubstances: boolean;
      compressedGases: boolean;
      illegalDrugs: boolean;
    };
    validDocuments: boolean;
    documentsExpiry: string;
    dangerousItems: string[];
    liquidVolume: string;
    medicalEquipment: string;
  };
  additionalInfo: {
    emergencyContact: string;
    medicalInfo: string;
    dietaryRestrictions: string;
  };
  sousTrajets: SousTrajet[];
}

const dossierData: Dossier = {
  idDossier: 4321,
  idPMR: 1,
  googleId: "QZc8mk3YpfcYRhZ2o9VNG96IAQs1",
  enregistre: true,
  bagage: {
    bagagesList: [1111, 2222],
    specialBagage: ""
  },
  specialAssistance: {
    wheelchair: false,
    visualAssistance: false,
    hearingAssistance: false,
    otherAssistance: ""
  },
  security: {
    securityQuestions: {
      packedOwn: false,
      leftUnattended: false,
      acceptedItems: false,
      receivedItems: false,
      dangerousGoods: false
    },
    declarations: {
      weaponsFirearms: false,
      explosives: false,
      flammableMaterials: false,
      radioactiveMaterials: false,
      toxicSubstances: false,
      compressedGases: false,
      illegalDrugs: false
    },
    validDocuments: false,
    documentsExpiry: "",
    dangerousItems: [],
    liquidVolume: "",
    medicalEquipment: ""
  },
  additionalInfo: {
    emergencyContact: "",
    medicalInfo: "",
    dietaryRestrictions: ""
  },
  sousTrajets: [
    {
      BD: "SNCF",
      numDossier: 1234,
      statusValue: 0,
      departure: "Courbevoie",
      arrival: "CDG",
      departureTime: "2024-12-23T03:25:44.000Z",
      arrivalTime: "2024-12-24T04:25:44.000Z"
    },
    {
      BD: "SNCF",
      numDossier: 5678,
      statusValue: 0,
      departure: "CDG",
      arrival: "Courbevoie",
      departureTime: "2024-12-23T05:25:44.000Z",
      arrivalTime: "2024-12-24T06:25:44.000Z"
    },
    {
      BD: "SNCF",
      numDossier: 9999,
      statusValue: 1,
      departure: "Paris",
      arrival: "Lyon",
      departureTime: "2024-12-24T03:25:44.000Z",
      arrivalTime: "2024-12-24T05:25:44.000Z"
    },
    {
      BD: "SNCF",
      numDossier: 9921,
      statusValue: 3,
      departure: "Lille",
      arrival: "Lyon",
      departureTime: "2024-12-24T07:25:44.000Z",
      arrivalTime: "2024-12-24T09:25:44.000Z"
    }
  ]
};

const calculateProgression = (sousTrajets: { statusValue: number }[]) => {
  if (sousTrajets.length === 0) return 0;

  const hasTermine = sousTrajets.some((s) => s.statusValue === 2);
  const hasEnCours = sousTrajets.some((s) => s.statusValue === 1);

  if (hasTermine) return 100;
  if (hasEnCours) return 50;
  return 0;
};

const MesTrajets: React.FC = () => {
  const [filtre, setFiltre] = useState("");
  const [trajets, setTrajets] = useState<Trajet[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [progression, setProgression] = useState<number>(0);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      const transformedTrajets = dossierData.sousTrajets.map(trajet => ({
        id: trajet.numDossier.toString(),
        depart: trajet.departure,
        arrivee: trajet.arrival,
        heure: trajet.departureTime.slice(11, 16),
        date: trajet.departureTime.slice(0, 10),
        duree: `${((new Date(trajet.arrivalTime).getTime() - new Date(trajet.departureTime).getTime()) / 3600000).toFixed(0)}h`,
        statut: trajet.statusValue === 0 ? "à venir" : (trajet.statusValue === 1 ? "en cours" : "terminé"),
        progression: trajet.statusValue,
        sousTrajets: []
      }));
      setTrajets(transformedTrajets);

      const prog = calculateProgression(dossierData.sousTrajets);
      setProgression(prog);

      setIsLoading(false);
    }, 1000);
  }, []);

  const handleFiltreChange = (statut: string) => {
    setFiltre(statut);
  };

  const handleSelectTrajet = (id: string) => {
    console.log("Trajet sélectionné:", id);
  };

  const handleViewDetails = (id: string) => {
    console.log("Détails du trajet:", id);
  };

  return (
    <div className="flex-grow p-6">
      <HomeNavbar navLight={true} bgLight={true} />
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">📍 Mes Trajets</h1>
          <p className="text-gray-600">Visualisez et gérez tous vos trajets</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-10">
            <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            <FiltreTrajets onFiltreChange={handleFiltreChange} />

            <div className="mt-6">
              <h2 className="text-xl font-semibold mb-4">Trajets {filtre && `(${filtre})`}</h2>
              <TrajetList filtre={filtre} onSelectTrajet={handleSelectTrajet} onViewDetails={handleViewDetails} trajets={trajets} />
            </div>

            <div className="mt-10">
              <h2 className="text-xl font-semibold mb-4">Résumé des activités</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h3 className="font-medium text-gray-700">Trajets à venir</h3>
                  <p className="text-2xl font-bold mt-2">{trajets.filter(t => t.statut === "à venir").length}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h3 className="font-medium text-gray-700">Trajets en cours</h3>
                  <p className="text-2xl font-bold mt-2">{trajets.filter(t => t.statut === "en cours").length}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h3 className="font-medium text-gray-700">Trajets terminés</h3>
                  <p className="text-2xl font-bold mt-2">{trajets.filter(t => t.statut === "terminé").length}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h3 className="font-medium text-gray-700">Progression globale</h3>
                  <p className="text-2xl font-bold mt-2">{progression}%</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default MesTrajets;